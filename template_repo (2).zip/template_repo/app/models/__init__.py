"""Data shapes."""
