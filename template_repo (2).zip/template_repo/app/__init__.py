"""The service package."""
